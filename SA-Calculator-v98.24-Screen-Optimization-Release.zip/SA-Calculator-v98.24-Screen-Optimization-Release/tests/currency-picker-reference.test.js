'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ROOT = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(ROOT, 'assets/js/app.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'assets/css/app.css'), 'utf8');

test('currency picker catalogue matches the 105 visible currency rows in the supplied reference video', () => {
  const match = app.match(/const CURRENCY_CATALOG = (\[[^;]+\]);/);
  assert.ok(match, 'currency catalogue is missing');
  const codes = JSON.parse(match[1].replace(/'/g, '"'));
  assert.equal(codes.length, 105);
  assert.equal(new Set(codes).size, 105, 'duplicate currency options');
  const namesBlock = app.match(/const CURRENCY_DISPLAY_NAMES = \{([\s\S]*?)\n\};/);
  assert.ok(namesBlock, 'currency display-name registry is missing');
  for (const code of codes) assert.match(namesBlock[1], new RegExp(`\\\"${code}\\\"\\s*:`), `missing display name for ${code}`);
  for (const [code, label] of [['MKD','Macedonian Denar'],['HUF','Hungarian Forint'],['KZT','Kazakhstani Tenge'],['AED','United Arab Emirates Dirham'],['NGN','Naira'],['NZD','New Zealand Dollar'],['RWF','Rwandan Franc']]) assert.ok(namesBlock[1].includes(`\"${code}\": \"${label}\"`), `reference label mismatch for ${code}`);
  for (const code of ['ALL','DZD','AOA','ARS','AUD','AZN','BHD','BDT','BYN','BTN','BOB','BAM','BRL','GBP','BND','BGN','MMK','BIF','KHR','CAD','XAF','XOF','XPF','CLP','CNY','COP','CRC','HRK','CZK','DKK','DOP','EGP','ETB','EUR','FJD','GHS','HKD','HUF','ISK','INR','IDR','IRR','IQD','ILS','JPY','JOD','KZT','KES','KWD','KGS','LAK','LBP','MOP','MKD','MGA','MYR','MVR','MUR','MXN','MNT','MAD','NGN','NAD','NPR','TWD','NZD','NIO','NOK','OMR','PKR','PGK','PYG','PEN','PHP','PLN','QAR','RON','RUB','RWF','SAR','RSD','SCR','SGD','ZAR','KRW','LKR','SDG','SEK','CHF','SYP','TJS','TZS','THB','TND','TRY','TMT','UGX','UAH','AED','UYU','USD','UZS','VND','YER','ZMW']) assert.ok(codes.includes(code), `missing ${code}`);
  for (const code of ['XAG','XAU','XDR','XTS','XXX','BOV','CHE','CHW','CLF','COU','MXV','USN']) assert.ok(!codes.includes(code), `unexpected non-fiat option ${code}`);
});

test('currency picker has search, selected checkmark, alphabetical list and A-Z quick navigation', () => {
  for (const id of ['currency-picker-modal','currency-picker-search','currency-picker-list','currency-picker-index']) assert.match(html, new RegExp(`id="${id}"`));
  assert.match(app, /function openCurrencyPicker\(/);
  assert.match(app, /function renderCurrencyPickerList\(/);
  assert.match(app, /modal\.dataset\.currencyPickerWired === 'true'/);
  assert.match(app, /'ABCDEFGHIJKLMNOPQRSTUVWXYZ'\.split\(''\)/);
  assert.match(app, /aria-selected/);
  assert.match(app, /No currencies found/);
  assert.match(app, /currencyPickerTarget\.dispatchEvent\(new Event\('change'/);
  assert.match(css, /\.currency-picker-index/);
  assert.match(css, /\.currency-picker-modal\.active/);
});
