# SA Calculator v98.24 — Screen Optimization Release

- App version: `1.98.24-v98.24`
- Android versionCode: `1098024`
- Design baseline: the v98.23 reference-native dark UI (navy surfaces, blue actions, green results, four-column calculator keypad, categorized tool navigation and compact tool screens).
- Preserved: all 18 requested tool destinations, Favorites, scientific functions, history, memory, currency conversion, localization and settings.
- v98.24 improvements: dynamic viewport sizing, constrained active-screen layout, scroll containment, narrow-device layout, compact landscape calculator layout and Android WebView keyboard-resize metadata.
- Cache identity: `sa-calculator-v98-24-screen-optimized-dark`.

## Build

1. Upload this complete source ZIP to the repository root.
2. Replace `.github/workflows/main.yml` with the supplied `main-v98.24-screen-optimization.yml` (or use the copy in this ZIP at `.github/workflows/main.yml`).
3. Commit and run the single active `SA Calculator v98.24 - Screen Optimization Android APK` workflow.
4. Download the artifact named `SA-Calculator-Debug-APK-1.98.24-v98.24`.
5. Install it and verify Settings → About & Support reports `v1.98.24-v98.24` before judging the new UI.

The local regression suite and web-bundle preparation must pass before the workflow reaches Gradle. A successful source test is not a substitute for installing the APK on the target phone and comparing screenshots at the phone's actual resolution/font scale.
