# SA Calculator v98.23 — release identity and reference UI gate

## Source baseline
- Continues the v98.22 reference rebuild: native dark navy UI, compact app bars, four-tab bottom navigation, categorized tools drawer, four-column calculator keypad, blue primary actions, green result cards, and reference layouts for Sales Tax, Loan/EMI, Tip, Unit Price, World Time and Settings.
- Retains the remaining registered tools and calculation engines.
- Release identity is now 1.98.23-v98.23 / Android versionCode 1098023.
- Service-worker cache key is advanced so an older web bundle is not intentionally reused.

## Release lock
- GitHub workflow requires exactly 1.98.23-v98.23 and rejects a stale source root/archive.
- Runtime APP_VERSION, HTML build marker, PWA manifest, service-worker cache and APK versionName/versionCode are checked.
- All workflow copies are kept byte-identical.

## Verification boundary
Local source tests and static checks can verify source consistency, calculation logic and packaging inputs. A GitHub-hosted Android build and physical Android installation/screenshot comparison are still required. The previous supplied recording visibly reported 1.98.19-v98.19, so it cannot be used as evidence of this release. No claim of pixel-perfect rendering or zero bugs is made before testing the actual v98.23 APK on the target phone.
