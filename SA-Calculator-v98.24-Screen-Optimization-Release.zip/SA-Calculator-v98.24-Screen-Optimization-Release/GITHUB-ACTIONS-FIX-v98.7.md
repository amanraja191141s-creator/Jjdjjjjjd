# GitHub Actions workflow fix — v98.7

## Confirmed failure
The Actions log shows `npm install` running in the Git checkout root, where `package.json` is absent. The project files are nested one directory below that root, so npm exits with `ENOENT` before any app tests or Android steps run.

## Correction
- Added an application-root discovery step that searches up to five directory levels for `package.json`.
- All Node, test, web-bundle, Capacitor and Gradle steps now execute relative to the discovered application root.
- The workflow fails early with a clear diagnostic if no manifest or multiple ambiguous manifests are found.
- Existing native Android projects are synced; a new project is generated only when `android/gradlew` is absent. An incomplete `android/` directory is not overwritten.
- Added bundle-output checks for `www/index.html`, the service worker, app JavaScript and CSS.
- Updated the Android workflow regression test to guard against the nested-root regression.

## Verification
- `node --test tests/*.test.js`: 150 passed, 0 failed.
- The source package contains one app `package.json` and the workflow discovers it rather than assuming the checkout root.
- This local verification does not execute GitHub-hosted Actions, download npm dependencies or compile an APK. The next GitHub Actions run is required to confirm the hosted runner and Android SDK build end-to-end.
