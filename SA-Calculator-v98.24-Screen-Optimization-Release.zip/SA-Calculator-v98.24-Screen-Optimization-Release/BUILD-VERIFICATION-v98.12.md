# SA Calculator v98.12 — Premium Android UI and converter repair

## Implemented
- New premium SA app icon generated and installed as the canonical 1024×1024 app/PWA icon.
- Android density launcher icons and adaptive icon resources added for mdpi through xxxhdpi.
- New `scripts/patch-android-native.mjs` copies launcher icons into the generated Capacitor Android project and patches all generated `AppTheme` styles with a dark navy status/navigation bar and light system icons.
- GitHub workflow now runs `npm run android:brand` after Capacitor sync and before Gradle compilation.
- Safe-area top/bottom viewport support and final premium responsive styling applied across shared cards, controls, keypad, dialogs, and screen layouts.
- Currency Converter layout refined for narrow and short screens, with clearer pair cards, amount fields, swap control, and rate status metadata.
- Removed contradictory `data-readonly=true` from the destination amount because the existing converter intentionally supports editing either amount and reverse calculation.
- Release/cache identity bumped to `1.98.12-v98.12`.

## Local verification
- `node --test tests/*.test.js`: 155 passed, 0 failed.
- `node scripts/prepare-android-web.mjs`: passed; required web assets copied.
- `node --check assets/js/app.js`: passed.
- `node --check scripts/patch-android-native.mjs`: passed.
- Native branding patch exercised against a simulated Capacitor Android resource tree: icon copying and theme XML patch passed.
- ZIP integrity checked after packaging.

## Not yet verified
- The actual uploaded `app-debug.apk` was not attached in this conversation, so no binary inspection, manifest inspection, decompilation, install test, or device runtime diagnosis was possible.
- This environment does not have the generated Android project/Gradle wrapper or Android SDK. Final Capacitor sync, Gradle build, APK installation, status-bar behavior on the user's device, and live currency-provider behavior must be verified by GitHub Actions and physical Android testing.
- Currency conversion logic was retained because the v98.11 source already had dedicated tests for decimal precision, provider freshness, reverse editing, pair swap, caching, and retry behavior. This update repairs converter presentation and contradictory editable-field metadata; unspecified device-only currency failures still need the APK or reproduction steps.
