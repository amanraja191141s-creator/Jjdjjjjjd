# SA Calculator v98.21 — verification record

## Completed in this session
- Regression tests: **174 passed, 0 failed, 0 skipped**.
- JavaScript syntax checks: **PASS** for app, localization, currency names, theme bootstrap, server, service worker and Android scripts.
- Android web bundle: **PASS**, generated from current source with required assets and service worker.
- Workflow YAML: **PASS**, canonical workflow, embedded workflow and standalone downloadable workflow parsed.
- Workflow parity: **PASS**, `.github/workflows/main.yml` and `android-apk.yml` are identical.
- Release metadata: package, UI, manifest and runtime version are `1.98.21-v98.21`; service-worker cache identity is v98.21.
- Source ZIP: archive integrity checked after packaging.

## Enforced by GitHub Actions
- Selects newest candidate but refuses to build unless selected source is exactly `1.98.21-v98.21`.
- Runs npm install, dependency verification, JS syntax checks, complete regression tests and Android web-bundle checks.
- Syncs Capacitor, applies Android launcher branding and edge-to-edge inset patch, builds `assembleDebug`.
- Inspects APK metadata and fails unless `versionName=1.98.21-v98.21` and `versionCode=1098021`.
- Uploads a version-labelled APK artifact.

## Not claimed as completed locally
GitHub-hosted Gradle/APK execution and physical Android installation/rendering cannot be certified from this local session. The recording provided shows the old installed version `v1.98.19-v98.19`; install the v98.21 artifact and confirm its About screen before visual acceptance.
